
// Funciones

function nombreFuncion() {
  // Bloque de código
}

// Llamado a la funcion :

nombreFuncion()  // Recordar los parentesis para ejecutarla ;

// Parametros

function nombreFuncion(nombre, apellido, edad, peso, .... paramN) {
    // Bloque de código
}

// Llamado al a funcion con parametros

nombreFuncion('Edward', 'Monsalve', '24', '80', ...)


function alertarMensaje(nombre, edad, estatura) {
  alert('Mi nombre es : '+ nombre +' , tengo ' + + ' años y mi estatura es: ' + estatura + ' CM')
}

alertarMensaje('Edward', 24, '1.88')

// Respuestas
